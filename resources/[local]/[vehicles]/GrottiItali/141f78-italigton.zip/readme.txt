place 'italigton' folder in mods/update/x64/dlcpacks

add
 <Item>dlcpacks:/italigton/</Item>
in dlclist.xml in mods/update/update.rpf/common/data