Locales["fr"] = {
	["cash"] = "Éspèces",
	["black_money"] = "Argent sale",
	["player_nearby"] = "Le joueur sélectionné n'est plus près de vous.",
	["players_nearby"] = "Il n'y a personne près de vous.",
	["openinv_help"] = "Opens inventory of another player",
	["openinv_id"] = "Player ID",
	["no_permissions"] = "You don't have permissions to do that!",
	["no_player"] = "Didn't find player with given ID!",
	["player_inventory"] = "Player inventory"
}
